# Obsidian 1.12.7 — recovered package and readability reconstruction

This directory contains files extracted from the supplied Windows Electron installer, plus a formatting-only readability pass. It is **not the original development repository** and does not restore original TypeScript, module boundaries, comments, symbol names, tests, or build pipeline. The application bundle remains webpack-style bundled code with shortened identifiers.

## Contents

- `app/` — extracted renderer app, UI assets, translations, libraries, and metadata.
- `bootstrap/` — extracted Electron main process and runtime dependencies.
- `reconstructed/app.formatted.js` — Prettier-formatted copy of `app/app.js`.
- `reconstructed/main.formatted.js` — formatted copy of the Electron `bootstrap/main.js`.
- `reconstructed/enhance.formatted.js` — formatted copy of the renderer enhancement script.
- `reconstructed/app.formatted.css` — formatted copy of `app/app.css`.
- `bootstrap/package.json`, `app/package.json` — manifests preserved from the package.

The original extracted app files are left unchanged. No claim is made that the formatted copies are independently buildable or that formatting reconstructs original source.

## Using the package

The practical use is to inspect the packaged implementation or run the original application from a matching installed distribution. The two extracted package manifests are not a complete standalone build configuration: their dependencies refer to runtime-relative directories, and the distribution's native modules and Electron/Chromium runtime are version/platform-specific. Running the JavaScript files alone is not an application.

To compare a formatted file against the packaged one, use a diff, for example:

```sh
diff -u app/app.js reconstructed/app.formatted.js
```

Formatting changes whitespace and layout only; it does not de-minify module identifiers or recover missing source maps.
